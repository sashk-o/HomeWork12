﻿using HomeWork12.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HomeWork9.Models
{
    [ClientValidation]
    public class Client : IValidatableObject
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Birthday { get; set; }
        [GenderValidation(new[] { "Male", "Female" })]
        public string Gender { get; set; }
        public string PhoneNumber { get; set; }
        public string EMail { get; set; }
        public string Address { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();
            if (String.IsNullOrWhiteSpace(this.FirstName))
            {
                errors.Add(new ValidationResult("Field cannot be empty!", new List<string>() { "FirstName" }));
            }
            if (String.IsNullOrWhiteSpace(this.LastName))
            {
                errors.Add(new ValidationResult("Field cannot be empty!", new List<string>() { "LastName" }));
            }
            if (!this.EMail.Contains("@"))
            {
                errors.Add(new ValidationResult("You must enter e-mail with domain after symbol '@'", new List<string>() { "EMail" }));
            }
            return errors;
        }
    }
}
