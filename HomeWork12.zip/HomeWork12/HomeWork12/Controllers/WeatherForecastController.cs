﻿using HomeWork9.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork12.Controllers
{
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        public IActionResult AddClient([FromBody] Client c)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Client client = new Client
            {
                FirstName = c.FirstName,
                LastName = c.LastName,
                Birthday = DateTime.Now,
                Gender = c.Gender,
                Address = c.Address,
                EMail = c.EMail,
                PhoneNumber = c.PhoneNumber
            };

            return new ObjectResult(client);
        }
    }
}
