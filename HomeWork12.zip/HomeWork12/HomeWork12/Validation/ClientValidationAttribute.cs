﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using HomeWork9.Models;

namespace HomeWork12.Validation
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ClientValidationAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            Client client = value as Client;
            if (!client.PhoneNumber.StartsWith("+380"))
            {
                return false;
            }
            return true;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            Client client = value as Client;
            if (!client.PhoneNumber.StartsWith("+380"))
            {
                return new ValidationResult("PhoneNumber must start with +380", new List<string>() { "PhoneNumber" });
            }
            return ValidationResult.Success;
        }
    }
}
