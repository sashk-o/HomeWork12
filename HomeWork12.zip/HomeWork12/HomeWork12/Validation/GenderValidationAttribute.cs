﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace HomeWork12.Validation
{
    [AttributeUsage(AttributeTargets.Property)]
    public class GenderValidationAttribute : ValidationAttribute
    {
        string[] _names;
        public GenderValidationAttribute(string[] names)
        {
            _names = names;
            ErrorMessage = "Gender can be only Male or Female!";
        }
        public override bool IsValid(object value)
        {
            if (value != null && _names.Contains(value.ToString()))
                return true;
            return false;
        }
    }
}
